from functools import wraps

class StateMachine(object):
    """This is the base class for a scenario state machine

    In order to create your own scenario, subclass StateMachine and define
    methods for each state transition in the scenario.

    Each state corresponds with a TRAPZ trace point. Each method corresponds to
    an edge in the state machine graph. The method names are significant and
    uniquely identify the edge. If the state machine is in <fromState> and
    receives an event taking it to <toState>, the method
    '<fromState>__<toState>' is called. If the method returns True, the state
    transition is allowed; if it returns False the state transition is
    disallowed and the state machine remains in <fromState>.

    State transitions can also return StateMachine.FINISHED which indicates
    that the state machine has completed, or StateMachine.ERROR which indicates
    an error. Either one terminates the state machine, though FINISHED records
    the state elapsed time statistics while ERROR discards them. State
    transitions returning ERROR should write to stderr describing the problem.

    The docstring in each transition method is used to identify the state in
    the VCD trace. Keep it short - single letters are best.

    The initial state is 'START'. All other states are named after the events
    that caused the state machine to enter that state. Events with named
    components and traces are named '<componentName>_<traceName>'. Otherwise
    they are named 'C<componentId>_T<traceId>'.

    The StateMachine base class also defines decorators which are used
    to perform typical tasks during a state transition (such as checking
    the elapsed time in the state transition)."""

    ERROR = "Error"
    FINISHED = "Finished"

    # Period in seconds over which to count occurances
    COUNT_INTERVAL = None

    @classmethod
    def PrintSubclasses(cls, clss):
        if not len(clss.__subclasses__()):
            print "No scenarios."
            return
        if (clss.__class__.__name__ == "StateMachine"):
            print "%-30s%s" % ("NAME", "DESCRIPTION")
            print "%-30s%s" % ("====", "===========")
        for subcls in clss.__subclasses__():
            if hasattr(subcls, "NAME"):
                print "%-30s%s" % (subcls.NAME, subcls.DESCRIPTION)
            else:
                StateMachine.PrintSubclasses(subcls)

    @classmethod
    def LookupSubclass(cls, clss, lookupName):
        for subcls in clss.__subclasses__():
            if hasattr(subcls, "NAME"):
                if subcls.NAME == lookupName:
                    return subcls
            else:
                return StateMachine.LookupSubclass(subcls, lookupName)
        return None

    def __init__(self):
        self.state = "START"
        # how many states have we seen?
        self.stateCount = 0
        # time of the state transition out of start state
        self.startTimestamp = None
        # time of the most recent state transition
        self.timestamp = None
        # this is a dictionary storing the elapsed time for each state transition
        self.elapsed = {}
        # this is a list of states and timestamps
        self.history = []
        # this is a list of state transitions (used to impose an order on self.elapsed)
        self.order = []

    def ProcessEvent(self, event, xml):
        """See if we can transition to a new state based on our current state
        and the next event. Return True if we made a state transition,
        False otherwise."""
        newState = event.State(xml)
        transitionName = '%s__%s' % (self.state, newState)
        try:
            transitionFn = getattr(self, transitionName)
        except AttributeError:
            return False
        result = transitionFn(event)
        if result and result != self.ERROR:
            if self.timestamp:
                # record elapsed time (except for first transition out of START)
                assert transitionName not in self.elapsed
                self.elapsed[transitionName] = event.timestamp - self.timestamp
                self.order.append(transitionName)
            else:
                self.startTimestamp = event.timestamp
            self.state = newState
            self.timestamp = event.timestamp
            # States have a "short name" that is used in VCD trace. If the state
            # transition function has a docstring we use that as short name, but if
            # there's no docstring we just use consecutive letters of the alphabet.
            shortName = transitionFn.__doc__
            if not shortName:
                assert self.stateCount < 26
                shortName = chr(ord('A') + self.stateCount)
            self.history.append((self.timestamp, self.state, shortName))
            self.stateCount += 1
        if result == self.FINISHED:
            # also record total elapsed time
            assert "TOTAL" not in self.elapsed
            self.elapsed["TOTAL"] = event.timestamp - self.startTimestamp
            self.order.append("TOTAL")

        return result

    #
    # The following are decorators for transition methods.
    #
    # This is one of the nastier things you can do in Python.
    # For more info see:
    #   http://www.artima.com/weblogs/viewpost.jsp?thread=240845
    #
    @staticmethod
    def minElapsed(limitSeconds):
        """This is a decorator for transition methods in StateMachines. It
        supresses a state transition (forces it to return false) when the
        elapsed time in this transition is shorter than limitSeconds."""
        def elapsedLimitClosure(transitionMethod):
            @wraps(transitionMethod)
            def wrapper(self, event):
                if event.timestamp - self.timestamp < limitSeconds:
                    return False
                else:
                    return transitionMethod(self, event)
            return wrapper
        return elapsedLimitClosure

    @staticmethod
    def maxElapsed(limitSeconds):
        """This is a decorator for transition methods in StateMachines. It
        supresses a state transition (forces it to return false) when the
        elapsed time in this transition is longer than limitSeconds."""
        def elapsedLimitClosure(transitionMethod):
            @wraps(transitionMethod)
            def wrapper(self, event):
                if event.timestamp - self.timestamp > limitSeconds:
                    return False
                else:
                    return transitionMethod(self, event)
            return wrapper
        return elapsedLimitClosure
