#!/bin/bash

trapzdir="${TRAPZ_DIR:?"export this var for directory with trapztool.py"}"
trapztool="$trapzdir/trapztool.py"
original_pythonpath=$PYTHONPATH
export PYTHONPATH="$trapzdir:$PYTHONPATH"

tmpfile="${TRAPZ_LOG_DIR:-/tmp}/trapz-check_dvfs.xml"
vcd_file="${TRAPZ_LOG_DIR:-/tmp}/trapz-check_dvfs.vcd"

echo "Clearing trapz events"

#adb shell trapz -r -- if desired to reset all
adb shell trapz -c
if [ $? -ne 0 ]
then
    echo "FAIL: Clearing trapz events was unsuccessul."
    exit -1
fi
echo "Unfilter DVFS events"

python trapztool.py filter DVFS verbose
if [ $? -ne 0 ]
then
    echo "FAIL: Unfiltering DVFS event (compId-12) was unsuccessful."
    exit -1
fi
read -p "Press any key to stop... " -n1 -s
adb shell trapz -x > $tmpfile

"$(dirname "$0")/check_dvfs.py" $tmpfile
exit_code=$?
if [ $exit_code -eq 1 ]
then
    echo "No samples collected"
    exit -1
fi

$trapztool vcd --no-tids $tmpfile $vcd_file

# restore
export PYTHONPATH="$original_pythonpath"
